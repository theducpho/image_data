export const shuffled = (list) => list.sort(() => Math.random() - 0.5);
